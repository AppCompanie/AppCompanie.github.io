from selenium import webdriver

driver = webdriver.Chrome(executable_path="chromedriver.exe")
driver.get("https://www.amazon.com/")

search_bar = driver.find_element_by_id("twotabsearchtextbox")
achat = input("Quel objet veut-tu acheter ?")
search_bar.send_keys(achat)

button_search = driver.find_element_by_id("nav-search-submit-button")
button_search.click()

game = driver.find_element_by_class_name("s-image")
game.click()

shopping = driver.find_element_by_id("add-to-cart-button")
shopping.click()